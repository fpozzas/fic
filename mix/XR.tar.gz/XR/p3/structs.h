struct juego{
	int operacion;
	int dato;
};
