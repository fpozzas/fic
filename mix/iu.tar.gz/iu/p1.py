 #!/usr/bin/env python


import pygtk
import gtk

w = gtk.Window()

# Preliminares
def salir(widget, data=None):
	gtk.main_quit()

w.connect("delete_event", salir)
w.set_title("Practica1")

# Para el menú: itemfactory

# Una toolbar
toolbar = gtk.Toolbar()

toolbar.show()

w.show()
gtk.main()
